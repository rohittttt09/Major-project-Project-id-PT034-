package com.digitaltwin.datacenter;

import com.digitaltwin.datacenter.model.DataCenterStatus;
import com.digitaltwin.datacenter.model.OptimizationResult;
import com.digitaltwin.datacenter.model.PredictionResult;
import com.digitaltwin.datacenter.service.DataCenterService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DataCenterServiceTest {
    @Test
    void statusHasValidPowerAndPue() {
        DataCenterService service = new DataCenterService();
        DataCenterStatus status = service.getStatus();
        assertTrue(status.totalPowerKw() > 0);
        assertTrue(status.itPowerKw() > 0);
        assertEquals(status.totalPowerKw() / status.itPowerKw(), status.pue(), 0.02);
    }

    @Test
    void predictionIsClearlyMarkedAsDemoEstimate() {
        PredictionResult prediction = new DataCenterService().predictEnergy();
        assertEquals("DEMO_ESTIMATE", prediction.status());
        assertTrue(prediction.predictedPowerKw() > 0);
    }

    @Test
    void optimizationReturnsSavingAndSafetyStatus() {
        OptimizationResult result = new DataCenterService().optimizeEnergy();
        assertTrue(Double.isFinite(result.estimatedSavingPct()));
        assertNotNull(result.recommendation());
    }
}
