package com.digitaltwin.datacenter.model;

import java.time.Instant;

public record OptimizationResult(
        String method,
        Instant generatedAt,
        double baselinePowerKw,
        double proposedPowerKw,
        double estimatedSavingPct,
        double proposedCoolingLevelPct,
        boolean temperatureConstraintSatisfied,
        String recommendation,
        String disclaimer
) {}
