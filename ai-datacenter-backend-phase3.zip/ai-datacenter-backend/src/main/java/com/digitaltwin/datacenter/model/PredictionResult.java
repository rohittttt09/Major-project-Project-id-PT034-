package com.digitaltwin.datacenter.model;

import java.time.Instant;

public record PredictionResult(
        String method,
        String status,
        Instant generatedAt,
        int predictionHorizonMinutes,
        double currentPowerKw,
        double predictedPowerKw,
        String explanation
) {}
