package com.digitaltwin.datacenter.model;

import java.time.Instant;
import java.util.List;

public record DataCenterStatus(
        String project,
        String mode,
        Instant timestamp,
        int totalServers,
        int activeServers,
        double workloadPct,
        double temperatureC,
        double itPowerKw,
        double coolingPowerKw,
        double otherPowerKw,
        double totalPowerKw,
        double pue,
        List<String> notes
) {}
