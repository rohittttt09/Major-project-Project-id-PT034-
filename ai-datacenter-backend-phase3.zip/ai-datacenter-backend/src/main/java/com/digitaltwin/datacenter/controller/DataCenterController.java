package com.digitaltwin.datacenter.controller;

import com.digitaltwin.datacenter.model.DataCenterStatus;
import com.digitaltwin.datacenter.model.OptimizationResult;
import com.digitaltwin.datacenter.model.PredictionResult;
import com.digitaltwin.datacenter.service.DataCenterService;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class DataCenterController {
    private final DataCenterService service;

    public DataCenterController(DataCenterService service) {
        this.service = service;
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of(
                "status", "UP",
                "application", "AI-Powered Digital Twin Backend",
                "timestamp", Instant.now().toString()
        );
    }

    @GetMapping("/datacenter/status")
    public DataCenterStatus status() {
        return service.getStatus();
    }

    @PostMapping("/simulation/next")
    public DataCenterStatus nextSimulationStep() {
        return service.nextSimulationStep();
    }

    @GetMapping("/energy/current")
    public Map<String, Object> currentEnergy() {
        DataCenterStatus s = service.getStatus();
        double energyPerHour = s.totalPowerKw();
        return Map.of(
                "itPowerKw", s.itPowerKw(),
                "coolingPowerKw", s.coolingPowerKw(),
                "otherPowerKw", s.otherPowerKw(),
                "totalPowerKw", s.totalPowerKw(),
                "pue", s.pue(),
                "estimatedEnergyForOneHourKwh", energyPerHour,
                "note", "One-hour energy estimate assumes the current power remains constant."
        );
    }

    @PostMapping("/predictions/run")
    public PredictionResult runPrediction() {
        return service.predictEnergy();
    }

    @GetMapping("/predictions/latest")
    public PredictionResult latestPrediction() {
        return service.predictEnergy();
    }

    @PostMapping("/optimization/run")
    public OptimizationResult optimize() {
        return service.optimizeEnergy();
    }
}
