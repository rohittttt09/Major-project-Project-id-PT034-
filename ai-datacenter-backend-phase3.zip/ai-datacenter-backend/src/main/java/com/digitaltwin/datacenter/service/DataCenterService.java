package com.digitaltwin.datacenter.service;

import com.digitaltwin.datacenter.model.DataCenterStatus;
import com.digitaltwin.datacenter.model.OptimizationResult;
import com.digitaltwin.datacenter.model.PredictionResult;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class DataCenterService {
    private int simulationStep = 0;
    private double workloadPct = 62.0;
    private double temperatureC = 26.5;

    public synchronized DataCenterStatus getStatus() {
        double itPower = round(3.0 + workloadPct * 0.085, 2);
        double coolingPower = round(0.9 + Math.max(0, temperatureC - 20) * 0.12, 2);
        double otherPower = 0.7;
        double totalPower = round(itPower + coolingPower + otherPower, 2);
        double pue = round(totalPower / itPower, 2);

        return new DataCenterStatus(
                "AI-Powered Digital Twin for Smart Data Centre and Energy Optimization",
                "SIMULATION",
                Instant.now(),
                10,
                9,
                round(workloadPct, 1),
                round(temperatureC, 1),
                itPower,
                coolingPower,
                otherPower,
                totalPower,
                pue,
                List.of(
                        "Values are simulated for the Phase 3 backend demonstration.",
                        "PUE is calculated as total facility power divided by IT power.",
                        temperatureC >= 30 ? "Warning: simulated temperature is above the configured 30 C threshold." : "Temperature is within the demo threshold."
                )
        );
    }

    public synchronized DataCenterStatus nextSimulationStep() {
        simulationStep++;
        // A repeatable wave plus small variation keeps the demo visibly changing.
        workloadPct = 35 + ((simulationStep * 13) % 55)
                + ThreadLocalRandom.current().nextDouble(-2.0, 2.0);
        workloadPct = Math.max(20, Math.min(95, workloadPct));
        temperatureC = 22 + (workloadPct * 0.075)
                + ThreadLocalRandom.current().nextDouble(-0.7, 0.7);
        temperatureC = Math.max(20, Math.min(34, temperatureC));
        return getStatus();
    }

    public PredictionResult predictEnergy() {
        DataCenterStatus current = getStatus();
        // Transparent baseline estimate for demo; this is NOT a trained ML model.
        double predicted = round(current.itPowerKw() * 1.06
                + current.coolingPowerKw() * 0.95
                + current.otherPowerKw(), 2);
        return new PredictionResult(
                "BASELINE_HEURISTIC_NOT_TRAINED_AI",
                "DEMO_ESTIMATE",
                Instant.now(),
                30,
                current.totalPowerKw(),
                predicted,
                "Illustrative 30-minute estimate using current simulated power and a fixed workload uplift. Replace with a trained model for genuine AI prediction."
        );
    }

    public OptimizationResult optimizeEnergy() {
        DataCenterStatus current = getStatus();
        double baseline = current.totalPowerKw();

        // Simple scenario comparison with explicit safety guard.
        double proposedCooling = current.temperatureC() > 28 ? 70 : 55;
        boolean safe = current.temperatureC() < 30;
        double proposedPower = safe
                ? round(current.itPowerKw() + current.coolingPowerKw() * 0.88 + current.otherPowerKw(), 2)
                : round(baseline, 2);

        double saving = baseline > 0 ? round((baseline - proposedPower) / baseline * 100, 2) : 0;
        String recommendation = safe
                ? "Demo recommendation: evaluate the proposed cooling setting in simulation; verify thermal limits before any real-world use."
                : "No energy-saving change recommended because the simulated temperature is at or above the demo safety threshold.";

        return new OptimizationResult(
                "RULE_BASED_SCENARIO_COMPARISON",
                Instant.now(),
                baseline,
                proposedPower,
                saving,
                proposedCooling,
                safe,
                recommendation,
                "Estimated simulation result only; not a measured or guaranteed real-world energy saving."
        );
    }

    private double round(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }
}
