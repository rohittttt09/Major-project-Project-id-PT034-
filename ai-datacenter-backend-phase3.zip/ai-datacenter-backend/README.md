# AI-Powered Digital Twin for Smart Data Centre and Energy Optimization
## Phase 3: Backend Demonstration

This is a small Spring Boot REST API that can be demonstrated locally in VS Code. It simulates a data centre and exposes status, energy, prediction-demo, and optimization-demo endpoints.

### Important project status
- Sensor values are simulated.
- Energy prediction is a transparent baseline heuristic, **not a trained AI/ML model yet**.
- Optimization is rule-based scenario comparison, not autonomous control of real equipment.
- No database is required for this quick demonstration; state is held in memory and resets when the app restarts.
- Do not connect this demo to real cooling or server controls.

### Requirements
- JDK 17 or later
- Maven 3.9+ installed and available as `mvn`
- Internet access on first build so Maven can download dependencies

Check:
```bash
java -version
mvn -version
```
Ensure Maven is using JDK 17 or later.

### Run in VS Code (Windows)
1. Extract the ZIP.
2. Open the extracted `ai-datacenter-backend` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:
```powershell
mvn spring-boot:run
```
5. Wait for the log line indicating the application has started on port 8080.
6. Open the endpoints listed below in your browser or test POST requests with Postman.

If `mvn` is not recognized, install Maven or use the Maven extension in VS Code. If port 8080 is occupied, stop the other app or change `server.port` in `src/main/resources/application.properties`.

### Endpoints
| Method | URL | Purpose |
|---|---|---|
| GET | `http://localhost:8080/api/health` | Confirm backend is up |
| GET | `http://localhost:8080/api/datacenter/status` | Digital Twin simulated state |
| GET | `http://localhost:8080/api/energy/current` | Power, PUE and one-hour energy estimate |
| POST | `http://localhost:8080/api/simulation/next` | Generate next simulated reading |
| POST | `http://localhost:8080/api/predictions/run` | Run baseline prediction demo |
| GET | `http://localhost:8080/api/predictions/latest` | Return a prediction demo |
| POST | `http://localhost:8080/api/optimization/run` | Run rule-based optimization demo |
| GET | `http://localhost:8080/actuator/health` | Spring Actuator health |

For POST endpoints, use Postman, or PowerShell:
```powershell
Invoke-RestMethod -Method Post http://localhost:8080/api/simulation/next
Invoke-RestMethod -Method Post http://localhost:8080/api/predictions/run
Invoke-RestMethod -Method Post http://localhost:8080/api/optimization/run
```

### Suggested guide demonstration (2-3 minutes)
1. Open `/api/health` and show `status: UP`.
2. Open `/api/datacenter/status` and explain simulated server workload, temperature, IT power, cooling power, total power, and PUE.
3. Open `/api/energy/current` and explain that kW is power and kWh is energy over time.
4. Use POST `/api/simulation/next`; refresh the status endpoint and show changing values.
5. Use POST `/api/predictions/run`; explicitly explain this is currently a baseline estimate, pending trained model integration.
6. Use POST `/api/optimization/run`; explain the result is a simulation-only recommendation.
7. Show the Java packages: controller handles HTTP requests, service contains simulation/calculation logic, model records define JSON responses.

### Build and test
```powershell
mvn test
mvn clean package
```
The JAR will be created under `target/`. Run it with:
```powershell
java -jar target/datacenter-backend-0.0.1-SNAPSHOT.jar
```

### Troubleshooting
- `mvn is not recognized`: Maven is not installed or PATH is not set.
- `Port 8080 was already in use`: stop the other application or change the port.
- Dependency download errors: check internet connection and retry.
- Java version error: check `java -version` and `mvn -version`; Maven should use JDK 17+.
